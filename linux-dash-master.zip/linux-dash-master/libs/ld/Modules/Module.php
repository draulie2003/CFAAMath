<?php

    namespace ld\Modules;

    class Module {
        protected $name = '';

        public function getData($args=array()) {
            return array();
        }
    }